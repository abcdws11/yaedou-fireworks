const canvas = document.getElementById('fireworksCanvas');
const ctx = canvas.getContext('2d');
canvas.width = canvas.offsetWidth;
canvas.height = canvas.offsetHeight;

function firework(x, y) {
  const particles = [];
  for (let i = 0; i < 30; i++) {
    particles.push({
      x, y,
      radius: Math.random() * 2 + 1,
      color: `hsl(${Math.random() * 360}, 100%, 70%)`,
      angle: Math.random() * 2 * Math.PI,
      speed: Math.random() * 3 + 2
    });
  }

  let frame = 0;
  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      p.x += Math.cos(p.angle) * p.speed;
      p.y += Math.sin(p.angle) * p.speed + frame * 0.1;
      p.radius *= 0.97;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, 2 * Math.PI);
      ctx.fillStyle = p.color;
      ctx.fill();
    });
    frame++;
    if (frame < 60) requestAnimationFrame(animate);
  }
  animate();
}

document.getElementById('fireBtn').addEventListener('click', () => {
  const x = Math.random() * canvas.width;
  const y = Math.random() * canvas.height * 0.5;
  firework(x, y);
});
